1) ติดตั้ง JDK 21 และ Gradle (ล่าสุด)
2) ในโฟลเดอร์นี้รัน:  gradle wrapper
3) บิลด์:  ./gradlew build   (Windows: gradlew build)
4) ไฟล์ม็อดอยู่ที่ build/libs/reachmod-1.0.0.jar  (ไม่ใช่ -sources)
5) ใส่ใน mods ของ Fabric 1.21.11 พร้อม Fabric API
ถ้าเวอร์ชันใน gradle.properties ผิด ดูค่าแนะนำที่ https://fabricmc.net/develop

เปิด/ปิดม็อดในเกม: พิมพ์ /reachmod ในแชท (สลับ ON/OFF)

บิลด์ออนไลน์ (ไม่ต้องลง JDK): อัปโหลดโฟลเดอร์นี้ขึ้น GitHub -> แท็บ Actions -> build -> ดาวน์โหลด artifact "reachmod"
