package net.reachmod;

import com.mojang.brigadier.Command;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.commands.Commands;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class ReachMod implements ModInitializer {
    static final Identifier ID = Identifier.fromNamespaceAndPath("reachmod", "boost");

    // ปรับตรงนี้: ระยะเริ่มต้น 4.5 + REACH_BONUS = ระยะใหม่
    static final double REACH_BONUS = 1.5;  // 6 บล็อก (ใส่ 0.5 = 5 บล็อก)
    static final double MINE_BONUS = 2.0;   // ความเร็วขุดเริ่มต้น 1 + 2 = 3 เท่า

    // ผู้เล่นที่ปิดม็อดไว้ (รีเซ็ตเมื่อปิดเกม/เซิร์ฟเวอร์)
    static final Set<UUID> DISABLED = new HashSet<>();

    @Override
    public void onInitialize() {
        // พิมพ์ /reachmod ในแชทเพื่อเปิด/ปิด
        CommandRegistrationCallback.EVENT.register((dispatcher, registry, env) ->
            dispatcher.register(Commands.literal("reachmod").executes(ctx -> {
                ServerPlayer p = ctx.getSource().getPlayerOrException();
                boolean nowOff = DISABLED.add(p.getUUID());
                if (!nowOff) DISABLED.remove(p.getUUID());
                String msg = nowOff ? "Reach Mod: OFF" : "Reach Mod: ON";
                ctx.getSource().sendSuccess(() -> Component.literal(msg), false);
                return Command.SINGLE_SUCCESS;
            })));

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayer p : server.getPlayerList().getPlayers()) {
                boolean on = !DISABLED.contains(p.getUUID());
                apply(p, Attributes.BLOCK_INTERACTION_RANGE, REACH_BONUS, on);
                apply(p, Attributes.BLOCK_BREAK_SPEED, MINE_BONUS, on);
            }
        });
    }

    static void apply(ServerPlayer p, Holder<Attribute> attr, double v, boolean on) {
        AttributeInstance a = p.getAttribute(attr);
        if (a == null) return;
        boolean has = a.hasModifier(ID);
        if (on && !has) a.addPermanentModifier(new AttributeModifier(ID, v, AttributeModifier.Operation.ADD_VALUE));
        else if (!on && has) a.removeModifier(ID);
    }
}
